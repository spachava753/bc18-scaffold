import bc.*;

class Extra {
    int x;

    Extra(int x) {
        this.x = x;
    }

    public String toString() {
        return "Extra: "+this.x;
    }
}