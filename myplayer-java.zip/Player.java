// import the API.
// See xxx for the javadocs.
import bc.*;

import java.util.Collection;
import java.util.LinkedList;

public class Player {
    private static GameController gc;
    private static LinkedList<Unit> workerList = new LinkedList();
    private static LinkedList<Unit> factoryList = new LinkedList();

    public static void main(String[] args) {
        // You can use other files in this directory, and in subdirectories.
        //Extra extra = new Extra(27);
        //System.out.println(extra.toString());

        // MapLocation is a data structure you'll use a lot.
        MapLocation loc = new MapLocation(Planet.Earth, 10, 20);
        System.out.println("loc: "+loc+", one step to the Northwest: "+loc.add(Direction.Northwest));
        System.out.println("loc x: "+loc.getX());

        // One slightly weird thing: some methods are currently static methods on a static class called bc.
        // This will eventually be fixed :/
        System.out.println("Opposite of " + Direction.North + ": " + bc.bcDirectionOpposite(Direction.North));

        // Connect to the manager, starting the game
        gc = new GameController();

        // Direction is a normal java enum.
        Direction[] directions = Direction.values();

        gc.queueResearch(UnitType.Worker);
        gc.queueResearch(UnitType.Rocket);
        gc.queueResearch(UnitType.Worker);
        gc.queueResearch(UnitType.Worker);
        gc.queueResearch(UnitType.Knight);
        gc.queueResearch(UnitType.Worker);
        gc.queueResearch(UnitType.Knight);
        gc.queueResearch(UnitType.Knight);
        gc.queueResearch(UnitType.Rocket);
        gc.queueResearch(UnitType.Rocket);

        replicateFirst();

        while (true) {
            System.out.println("Current round: "+gc.round());
            System.out.println("Harvested: "+gc.karbonite());
            if (workerList.size() < 50)
                 replicateFirst();

            // VecUnit is a class that you can think of as similar to ArrayList<Unit>, but immutable.
            VecUnit units = gc.myUnits();
            for (int i = 0; i < units.size(); i++) {
                Unit unit = units.get(i);

                if (unit.unitType() == UnitType.Worker) {
                    runWorker(unit);
                }

                // update our worker list
                updateList();
            }

            System.out.println("num of workers is " + workerList.size());
            System.out.println("num of factories is " + factoryList.size());
            System.out.println("---------FINISHED ROUND-------");
            // Submit the actions we've done, and wait for our next turn.
            gc.nextTurn();
        }
    }

    private static void updateList() {
        VecUnit vecUnit = gc.myUnits();
        for (long i = 0; i < vecUnit.size(); i++) {
            if (vecUnit.get(i).unitType() == UnitType.Worker){

                addWorkerToList:{
                    for (Unit unit : workerList) {
                        if (unit.id() == vecUnit.get(i).id()) {
                            break addWorkerToList;
                        }
                    }

                    workerList.add(vecUnit.get(i));
                }

            } else if (vecUnit.get(i).unitType() == UnitType.Factory){

                addFactoryToList: {
                    int count = 0;
                    for (Unit unit : factoryList) {
                        if (unit.id() == vecUnit.get(i).id()) {
                            break addFactoryToList;
                        }
                    }


                    factoryList.add(vecUnit.get(i));
                }
            }
        }
    }

    private static void replicateFirst() {
        VecUnit units = gc.myUnits();
        for (int i = 0; i < units.size(); i++) {
            Unit unit = units.get(i);

            for (Direction direction: Direction.values()) {
                if (gc.canReplicate(unit.id(), direction)) {
                    gc.replicate(unit.id(), direction);
                    break;
                }
            }

        }
    }

    public static void runWorker(Unit unit) {
        //System.out.println("Running worker");
        System.out.println("This worker's is is " + unit.id());

        /*
        if (gc.isMoveReady(unit.id())) {
            for (Direction direction: Direction.values()) {
                if (gc.canMove(unit.id(), direction)) {
                    gc.moveRobot(unit.id(), direction);
                    break;
                }
            }
        }
        */

        // harvest in all directions
        boolean noAdjacentKarbonite = true;
        for (Direction direction : Direction.values()){
            if (gc.canHarvest(unit.id(), direction)) {
                gc.harvest(unit.id(), direction);
                noAdjacentKarbonite = false;
            }
        }

        if (noAdjacentKarbonite) {
            // time to build factories!!
            if (factoryList.size() < 15) {
                // check if we are next a factory
                buildAround:{
                    for (Unit factory: factoryList) {
                        if (gc.canBuild(unit.id(), factory.id())) {
                            gc.build(unit.id(), factory.id());
                        }
                    }
                }

                blueprintArea:
                for (Direction direction : Direction.values()) {
                    if (gc.canBlueprint(unit.id(), UnitType.Factory, direction)) {
                        gc.blueprint(unit.id(), UnitType.Factory, direction);
                        break blueprintArea;
                    }
                }

            } else {
                // move randomly
                if (gc.isMoveReady(unit.id())) {
                    for (Direction direction: Direction.values()) {
                        if (gc.canMove(unit.id(), direction)) {
                            gc.moveRobot(unit.id(), direction);
                            break;
                        }
                    }
                }
            }
        }

    }

    private static int checkIfFactoryNeedsBuilding() {
        for (Unit unit : factoryList) {
            if (unit.unitType() == UnitType.Factory) {
                if (unit.structureIsBuilt() == 0) {
                    return factoryList.indexOf(unit);
                }
            } else {
                factoryList.remove(unit);
            }
        }

        return -1;
    }

    private static boolean checkIfOnMap(MapLocation mapLocation) {
        return gc.startingMap(gc.planet()).onMap(mapLocation);
    }
}